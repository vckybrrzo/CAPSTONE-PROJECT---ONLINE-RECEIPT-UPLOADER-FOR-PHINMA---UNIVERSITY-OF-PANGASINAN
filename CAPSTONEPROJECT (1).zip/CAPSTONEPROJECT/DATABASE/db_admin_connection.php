<?php


/*$host = "localhost";  Host name 
$user= "root";  User 
$password = "";  Password 
$dbname = "adminpanel";  Database name */

$adminconnection = mysqli_connect("localhost","root","","adminpanel"); //connecting to the database
// Check connection
if (!$adminconnection) {
 die("Connection failed: " . mysqli_connect_error()); //terminates the execution
}

