<?php require_once "controller_admin_data.php"; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,700;1,300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../CSS/login.css">
</head>
<body>
	<div class="hero-img"></div>
	<div class="container">
		
			<div class="title">
				<h1>Online Receipt Uploader for PHINMA-UNIVERSITY OF PANGASINAN</h1>
				<h2>Forgot<span>Password</span></h2>
			</div>	
			<?php
            if(count($errors) > 0){
                ?>
                <div class="alert alert-danger text-center">
                    <?php 
                        foreach($errors as $error){
                            echo $error;
                        }
                    ?>
                </div>
                <?php
            }
        ?>
				<form action="admin_forgot_password.php" method="POST">

			<div class="field">
				<input class="form-control" type="email" name="email" placeholder="Enter email address" required value="<?php echo $email ?>">
			</div>

			<div class="field">
			</div>
				
			
			<div class="button">
				 <input type="submit" name="check-email" value="CONTINUE" class="btn btn-secondary">
			</div>
		
		</form>
	</div>

</body>
</html>