<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php require 'BOOTSTRAP RESOURCES/PHPExcel/Classes/PHPExcel.php'?>
<?php require_once 'BOOTSTRAP RESOURCES/PHPExcel/Classes/PHPExcel/IOFactory.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!--SCRIPT FOR SEARCH BAR-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<!-- My CSS IN PAGINATION-->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
	<!-- My CSS -->
	<link rel="stylesheet" href="../CSS/style.css">
	<style type="text/css">
.modal-button{
	margin: 0em 0 1em 1em;
}
.modal-body .input-group input{
	margin-bottom: 2em;

}

.modal-body input{
	margin-bottom: 2em;

}

.modal-body select{
	margin-bottom: 2em;

}
	</style>

	<title>Admin</title>
</head>
<body>

	<!--PHP Getting Name-->
	<?php
	$id=$_SESSION['userName'];
	$adminquery="SELECT * FROM adminuseraccount WHERE userName='$id'";
	$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>
<!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run)){
		if($row['profilepicture']==""){
			$default ="<img src='adminprofilepicture/default.png' alt='default profile'";
			}
		else{
			$default ="<img src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
			}
	?>


	<!-- SIDEBAR -->
	<section id="sidebar" class="hide">
		<a href="#" class="brand">
			<i class='bx bx-archive-out'></i>
			<span class="text"><span>UPANG<span class="subtitle"> UPLOADER</span></span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li class="active">
				<a href="student.php">
					<i class='bx bxs-user-circle'></i>
					<span class="text">Students</span>
				</a>
			</li>
			<li>
				<a href="request.php">
					<i class='bx bxs-help-circle' ></i>
					<span class="text">Request</span>
				</a>
			</li>
			<li>
				<a href="user_account.php">
					<i class='bx bxs-group'></i>
					<span class="text">User Accounts</span>
				</a>
			</li>
			<li>
				<a href="user_logs.php">
					<i class='bx bxs-notepad'></i>
					<span class="text">User logs</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout_admin.php" onClick ="return confirm('Are you  sure you want to logout?');" class="logout">
					<i class='bx bxs-log-out'></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu'></i>
			<form action="#">
				<div class="form-input">
					<h3>Administration Center</h3>
				</div>
			</form>

<!--NOTIFICATION-->
			<div class="btn-group" role="group">
			    <button id="btnGroupDrop" type="button" class="btn dropdown-toggle " data-bs-toggle="dropdown" aria-expanded="false" style="background-color:transparent"><i class='bx bxs-bell'>
			    	
			<?php
				$requestquery="SELECT * FROM admin_notification WHERE status='0'";
				$requestquery_run = mysqli_query($adminconnection, $requestquery);
				$totalrequest = mysqli_num_rows($requestquery_run);
				if ($totalrequest>0) {
					echo "<span class='num'>$totalrequest</span>";
				}
				?>
			</i></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop">
		   	 	<?php 
		   	 	$requestquery1 =mysqli_query($adminconnection,"SELECT * FROM admin_notification WHERE status='0'");
				if (mysqli_num_rows($requestquery1)>0) {
					while($result =mysqli_fetch_assoc($requestquery1)){
						echo '<li><a class="dropdown-item" href="request.php?notif='.$result['id'].'">'.$result['name'].' '.$result['description'].'</a></li>';
						echo '<div class="dropdown-divider"></div>';
					}
				}
				else{
					echo '<li><a class="dropdown-item text-danger" href="">No notification</a></li>';
				}
				 ?>	
			    </ul>
		  	</div>
<!--NOTIFICATION-->

		<div class="btn-group" role="group">
		    <button id="btnGroupDrop1" type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Welcome, <?php echo strtoupper($row['userName']);?></button>
	   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
		      <li><a class="dropdown-item" href="admin_profile.php">profile</a></li>
		      <li><a class="dropdown-item" href="#">change password</a></li>
		    </ul>
	  	</div>

	  	<a href="#" class="profile">
				<?php echo $default;?> 
			</a>
		</nav>
<!-- NAVBAR -->

<?php 
}
	}
?>

<!-- MAIN -->
<main>
			<div class="head-title" style="margin-bottom: 2em;">
				<div class="left">
					<h1>Student Record</h1>
				</div>
				<a href="print_student_records.php" class="btn-download">
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Print Records</span>
				</a>
			</div>
 	

<button type="button" class="modal-button btn btn-warning" data-bs-toggle="modal" data-bs-target="#adminimportModal"><i class='bx bxs-cloud-upload'></i> Import Student Account</button>

<!-- Button trigger modal -->
<div class="modal-button">
	<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class='bx bxs-user-plus'></i> Add Student Account</button>
</div>


<?php  

?>

	<?php 
		$query = "SELECT * FROM studentaccount ORDER BY lastName ASC";
		$query_run = mysqli_query($studentconnection, $query);	
	?>	

	<div class="table-responsive table1">
		<table class="table table-hover table-bordered" id="datatable" cellspacing="0">
		<thead>
			<tr class="table-success">
				<th>Student Number</th>
				<th>Last Name</th>
				<th>First Name</th>
				<th>Password</th>
				<th>Email Address</th>
				<th>Contact Number</th>
				<th>Course</th>
				<th>Option</th>
			</tr>
		</thead>
		<tbody id="myTable">

			<?php
				if (mysqli_num_rows($query_run) >0) {
					while($row = mysqli_fetch_assoc($query_run))
					{	
				?>

				<tr>
					<td><?php echo $row['studentNumber'];?></td>
					<td><?php echo $row['lastName'];?></td>
					<td><?php echo $row['firstName'];?></td>
					<td><?php echo $row['password'];?></td>
					<td><a href=""><?php echo $row['email'];?></a></td>
					<td><?php echo $row['contact'];?></td>
					<td><?php echo $row['course'];?></td>
					<td style="text-align: center; align-content: center; width: 10em;"><form method="POST" action="">
						<a href="view_student.php?viewuser=<?php echo $row['studentNumber'];?>" class="btn btn-success btn-sm"><i class='bx bxs-show'></i></a>

						<a href="edit_form_student.php?edit=<?php echo $row['studentNumber'];?>" class="btn btn-primary btn-sm"><i class='bx bxs-edit-alt'></i></a>

						<a href="view_form_student.php?viewform=<?php echo $row['studentNumber'];?>" class="btn btn-warning btn-sm"><i class='bx bxs-file'></i></a>

						<a href="db_delete_student.php?delete=<?php echo $row['studentNumber'];?>" onClick ="return confirm('Do you really want to delete this record?');" class="btn btn-danger btn-sm"><i class='bx bxs-trash'></i></a>
						
					</form>
					</td>
				</tr>

					<?php
					}
				}
					else{
						?>
						<tr>
							<td colspan="7" style="text-align: center;">No record</td>
						</tr>
					<?php
				}

				?>

		</tbody>
	</table>
</div>
	
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 99999;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">ADD STUDENT ACCOUNT</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      	<form action="db_adding_student.php" method="POST" enctype="multipart/form-data">

        <div class="input-group">
			    <input type="text" placeholder="First Name" name="firstName" class="form-control" pattern="[A-Za-z ]" title="invalid format. please insert letters only" required>
			    <input type="text" placeholder="Last Name" name="lastName" class="form-control" pattern="[A-Za-z ]" title="invalid format. please insert letters only" required>
				</div>
					<input type="text" name="studentNumber" placeholder="Student Number" class="form-control" required>

					<select class="form-select" name="course" required>
								  <option disabled selected hidden>SELECT COURSE</option>
								  <option disabled style="font-weight: bold;">COLLEGE IF INFORMATION TECHNOLOGY</option>
								  <option value="Bachelor of Science in Information Technology">Bachelor of Science in Information Technology</option>
								  <option disabled style="font-weight: bold;">COLLEGE OF ENGINEERING AND ARCHITECTURE</option>
								  <option value="Bachelor of Science in Architecture">Bachelor of Science in Architecture</option>
								  <option value="Bachelor of Science in Civil Engineering">Bachelor of Science in Civil Engineering</option>
								  <option value="Bachelor of Science in Electrical Engineering">Bachelor of Science in Electrical Engineering</option>
								  <option value="Bachelor of Science in Electronics Engineering">Bachelor of Science in Electronics Engineering</option>
								  <option value="Bachelor of Science in Computer Engineering">Bachelor of Science in Computer Engineering</option>
									<option value="Bachelor of Science in Mechanical Engineering : PERMIT LEVEL">Bachelor of Science in Mechanical Engineering : PERMIT LEVEL</option>
								  <option disabled style="font-weight: bold;">COLLEGE OF SOCIAL SCIENCES</option>
								  <option value="Bachelor of Arts in Communication">Bachelor of Arts in Communication</option>
								  <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
								  <option value="Bachelor of Education">Bachelor of Education</option>
								  <option value="Bachelor of Education major in Pre-School Education">Bachelor of Education major in Pre-School Education</option>
								  <option value="Bachelor of Secondary Education major in Biological Science">Bachelor of Secondary Education major in Biological Science</option>
								  <option value="Bachelor of Secondary Education major in English">Bachelor of Secondary Education major in English</option>
								  <option value="Bachelor of Secondary Education major in Mathematics">Bachelor of Secondary Education major in Mathematics</option>
								  <option value="Bachelor of Science in Criminology">Bachelor of Science in Criminology</option>
								  <option disabled style="font-weight: bold;">COLLEGE OF MANAGEMENT AND ACCOUNTING</option>
								  <option value="Bachelor of Science in Accountancy">Bachelor of Science in Accountancy</option>
								  <option value="Bachelor of Science in Accounting Technology">Bachelor of Science in Accounting Technology</option>
								  <option value="Bachelor of Science in Business Administration major in Financial Management">Bachelor of Science in Business Administration major in Financial Management</option>
								  <option value="Bachelor of Science in Business Administration major in Marketing Management">Bachelor of Science in Business Administration major in Marketing Management</option>
								  <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
								  <option value="Bachelor of Science in Tourism Management">Bachelor of Science in Tourism Management</option>
								  <option disabled style="font-weight: bold;">COLLEGE OF HEALTH SCIENCES</option>
								  <option value="Bachelor of Science in Nursing">Bachelor of Science in Nursing</option>
								  <option value="Bachelor in Medical Laboratory Science">Bachelor in Medical Laboratory Science</option>
								  <option value="Bachelor of Science in Physical Therapy">Bachelor of Science in Physical Therapy</option>
								  <option value="Bachelor of Science in Pharmacy : PERMIT LEVEL">Bachelor of Science in Pharmacy : PERMIT LEVEL</option>
								  <option value="Diploma in Midwifery">Diploma in Midwifery</option>
								  <option value="Bachelor of Science in Midwifery">Bachelor of Science in Midwifery</option>
								</select>

					<input type="email" name="email" placeholder=" Email Address" class="form-control" required>
					<input type="text" name="contact" placeholder="Contact Number" class="form-control" pattern="[0-9]{11}" title="invalid number and use the proper format example: 09876543210" required>
								

      </div>
      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-success" name="addstudent">add</button>
    	</div>
     		</form>
    </div>
  </div>
</div>

<!--MODAL FOR IMPORT-->
<div class="modal fade" id="adminimportModal" tabindex="-1" aria-labelledby="adminimportModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="adminimportModalLabel">IMPORT EXCEL FILE</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
			<form action="" method="post" enctype="multipart/form-data">
				<input class="inputprofile btn btn-secondary" type="file" id="file_import" name="file" required 
				accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, .csv" onchange="return fileValidation()">
				<input type="submit" name="submit" class="btn btn-success">
			</form>	
      </div>
    </div>
  </div>
</div>
<!--MODAL FOR IMPORT-->

	</main>
<!-- MAIN -->
</section>
<!-- CONTENT -->
	
	<script src="script.js"></script>
<!-- My SCRIPT IN PAGINATION AND SEARCH-->
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
    $('#datatable').DataTable();
} );
	</script>
<!-- My SCRIPT IN PAGINATION AND SEARCH-->	

<!--POST METHOD FOR IMPORT-->
<?php
	if(isset($_POST['submit'])){
		$id=$_SESSION['userName'];

		$importfile=$_FILES['file']['tmp_name'];
		$objExcel=PHPExcel_IOFactory::load($importfile);

		foreach ($objExcel -> getWorksheetIterator() as $worksheet) {
			$highestrow = $worksheet -> getHighestRow();

			for($row=0;$row<=$highestrow;$row++){
				echo$fname=$worksheet->getCellByColumnAndRow(0,$row)->getValue();
				$lname=$worksheet->getCellByColumnAndRow(1,$row)->getValue();
				$student_ID=$worksheet->getCellByColumnAndRow(2,$row)->getValue();
				$email=$worksheet->getCellByColumnAndRow(3,$row)->getValue();
				$contact=$worksheet->getCellByColumnAndRow(4,$row)->getValue();
				$sem=$worksheet->getCellByColumnAndRow(5,$row)->getValue();
				$date=$worksheet->getCellByColumnAndRow(6,$row)->getValue();
				$amount=$worksheet->getCellByColumnAndRow(7,$row)->getValue();
				$image=$worksheet->getCellByColumnAndRow(8,$row)->getValue();
				$approval=$worksheet->getCellByColumnAndRow(9,$row)->getValue();

				if($fname!=''){
					$insertSql="INSERT INTO `student_form`( `firstname`, `lastname`,`student_id`,`email`,`contact`,`periodic`,`date`,`amount`,`image`,`approval`) VALUES ('".$fname."','".$lname."','".$student_ID."','".$email."','".$contact."','".$sem."','".$date."','".$amount."','".$image."','".$approval."')";
					$insertRes=mysqli_query($adminconnection,$insertSql);
				} 
			} 
		}

		echo "<script>alert('IMPORT SUCCESSFUL!');</script>";
        echo "<script>document.location='student.php';</script>";
	}
?>

<!--File Type Validation-->
	<script>
        function fileValidation() {
            var fileInput = 
                document.getElementById('file_import');
              
            var filePath = fileInput.value;
          
            // Allowing file type
            var allowedExtensions = 
				/(\.xlsx|\.csv)$/i;
              
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid File Type!');
                fileInput.value = '';
                return false;
            } 
        }
    </script>
</body>
</html>