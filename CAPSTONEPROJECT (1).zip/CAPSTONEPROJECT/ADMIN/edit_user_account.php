<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php 
	if(isset($_POST['update'])){
		$id=$_GET['edit'];
		$userLevel= $_GET['userLevel'];
		$adminuser= $_SESSION['userName'];
		$firstName= $_POST['firstName'];
		$lastName= $_POST['lastName'];
		$userName= $_POST['userName'];
		$password= $_POST['password'];
		$email= $_POST['email'];
		$contact= $_POST['contact'];

/*		
$checkusername = mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE  userName='$adminuser' AND userName ='$userName'");
	if(mysqli_num_rows($checkusername)>0){
				echo "<script>alert('Username was already exist');</script>";
				echo "<script>document.location='edit_user_account.php';</script>";
				exit();
	}
*/	
		$sql = "";
		if($userLevel == "admin"){
			$sql = mysqli_query($adminconnection, "UPDATE adminuseraccount SET firstName='$firstName', lastName='$lastName', userName='$userName', password='$password', email='$email', contact='$contact' WHERE userName='$id'");
		}
		// if secretary
		else{
			$sql = mysqli_query($adminconnection, "UPDATE secretaryuseraccount SET firstName='$firstName', lastName='$lastName', userName='$userName', password='$password', email='$email', contact='$contact' WHERE userName='$id'");
		}
		

		if($sql){
			echo "<script>alert('A account was updated successfully')</script>";
			echo "<script>document.location='user_account.php';</script>";
			?>
			 <!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM studentaccount WHERE studentNumber='$id'";
			$studentquery_run = mysqli_query($studentconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstName= $row['firstName'];
			$lastName= $row['lastName'];
			$studentNumber= $row['studentNumber'];

			$action='Edit a user account [NAME: '.$firstName.' '.$lastName.' STUDENT NUMBER: '.$studentNumber.' COURSE: '.$course.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
			<?php			
		}
		else{
			echo "<script>alert('Something went wrong!')</script>";
			echo "<script>document.location='edit_student_account.php';</script>";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<title>Edit Student Account</title>
	<!-- My CSS -->
	<style type="text/css">
.container{
 margin-top: 3rem;
 text-align: center;
 width: 50%;
}
h1{
	margin-bottom: 1em;
}
.form-control{
	margin-bottom: 1em;
}

.form-select{
	margin-bottom: 1em;
}	

label{
	float: left;
	font-weight: bold;
}
div .button{
	text-align: right;
	display: block;
}
</style>

</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Edit Student Account</h1>
			</div>
		</div>

			<?php 
				$id= $_GET['edit'];
				$userLevel= $_GET['userLevel'];
				$sql = "";
				if($userLevel == "admin"){
					$sql= mysqli_query($adminconnection, "SELECT * FROM adminuseraccount WHERE userName ='$id'");
				}
				// if secretary
				else{
					$sql= mysqli_query($adminconnection, "SELECT * FROM secretaryuseraccount WHERE userName ='$id'");
				}

					while ($row=mysqli_fetch_assoc($sql)){
			?>

		<form method="POST">	
			<div class="row">
				<div class="col-md-6">
					<label>First Name</label>
					<input type="text" name="firstName" value="<?php echo $row['firstName'];?>" class="form-control" placeholder="First Name" required>
				</div>	
				<div class="col-md-6">
					<label>Last Name</label>
					<input type="text" name="lastName" value="<?php echo $row['lastName'];?>" class="form-control" placeholder="Last Name" required>
				</div>	
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Username</label>
				<input type="text" name="userName" value="<?php echo $row['userName'];?>" class="form-control" placeholder="Student Number" required readOnly>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Password</label>
				<input type="text" name="password" value="<?php echo $row['password'];?>" class="form-control" placeholder="Password" required>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Email</label>
				<input type="text" name="email" value="<?php echo $row['email'];?>" class="form-control" placeholder="Email" required>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
				<label>Contact Number</label>
				<input type="text" name="contact" value="<?php echo $row['contact'];?>" class="form-control" placeholder="Contact" pattern="[0-9]{11}" title="invalid number and use the proper format example: 09876543210" required>
				</div>

			<?php
				 }
			 ?>

			
			<div class="button">
			<a href="user_account.php" type="button" class="btn btn-secondary">BACK</a>
			<button type="text" name="update" class="btn btn-primary" onClick ="return confirm('Do you really want to update this account?');">UPDATE</button>
			</div>
		</form>
	</div>

</body>
</html>