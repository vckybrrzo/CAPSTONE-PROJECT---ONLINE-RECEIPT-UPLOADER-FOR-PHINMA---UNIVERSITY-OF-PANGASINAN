<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="../CSS/style.css">
	<style type="text/css">
		.container{
	width: 80;
	background: lightgreen;
	padding: 40px;
	text-align: center;
	margin: auto;
	margin-top: 2%;

}


img{
	border-radius: 50%;
}

	</style>

	<title>Dashboard</title>
</head>
<body>
<!--PHP Getting Name-->
	<?php
	$id=$_SESSION['userName'];
	$adminquery="SELECT * FROM adminuseraccount WHERE userName='$id'";
	$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>
<!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run)){
		if($row['profilepicture']==""){
			$default ="<img src='adminprofilepicture/default.png' alt='default profile'";
			}
		else{
			$default ="<img src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
			}
	?>
	<!-- SIDEBAR -->
	<section id="sidebar" class="hide">
		<a href="#" class="brand">
			<i class='bx bx-archive-out'></i>
			<span class="text"><span>UPANG<span class="subtitle"> UPLOADER</span></span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="#">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="student.php">
					<i class='bx bxs-user-circle'></i>
					<span class="text">Students</span>
				</a>
			</li>
			<li>
				<a href="request.php">
					<i class='bx bxs-help-circle' ></i>
					<span class="text">Request</span>
				</a>
			</li>
			<li>
				<a href="user_account.php">
					<i class='bx bxs-group'></i>
					<span class="text">User Accounts</span>
				</a>
			</li>
			<li>
				<a href="user_logs.php">
					<i class='bx bxs-notepad'></i>
					<span class="text">User logs</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout_admin.php" onClick ="return confirm('Are you  sure you want to logout?');" class="logout">
					<i class='bx bxs-log-out'></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu'></i>
			<form action="#">
				<div class="form-input">
					<h3>Administration Center</h3>
				</div>
			</form>
			<a href="request.php" class="notification">
				<i class='bx bxs-bell'></i>

<!--NOTIFICATION-->
			<?php
				$requestquery="SELECT * FROM student_form WHERE approval=''";
				$requestquery_run = mysqli_query($adminconnection, $requestquery);
				$totalrequest = mysqli_num_rows($requestquery_run);
				if ($totalrequest>0) {
					echo "<span class='num'>$totalrequest</span>";
				}
				?>
<!--NOTIFICATION-->
		
			</a>
			<div class="btn-group" role="group">
			    <button id="btnGroupDrop1" type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><?php echo strtoupper($row['userName']);?></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
			      <li><a class="dropdown-item" href="admin_profile.php">profile</a></li>
			      <li><a class="dropdown-item" href="#">change password</a></li>
			    </ul>
		  	</div>
			<a href="#" class="profile">
			<?php echo $default;?> 
			</a>
					
		</nav>
		<!-- NAVBAR -->

<?php 
}
	}
?>

		<!-- MAIN -->
		<main>
				<div class="container">
			 <!--PHP Getting Name-->
				<?php
				$id=$_SESSION['userName'];
		$adminquery="SELECT * FROM adminuseraccount WHERE userName='$id'";
		$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>


 <!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run))
		{
			if($row['profilepicture']==""){
					$default ="<img width='200' height='200' src='adminprofilepicture/default.png' class='circle' alt='default profile'";
				}
				else{
					$default ="<img width='200' height='200' src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
					}
	?>
			<?php  echo $default;?> <br><br><br>

	<!-- BUTTON FOR UPDATING PROFILE -->
				<button type="button" class="upload btn btn-primary" data-bs-toggle="modal" data-bs-target="#adminprofileModal">UPDATE PROFILE</button>
				<br><br>
				<h2 class="content"><?php echo  $row['firstName'],' ', $row['lastName'];?></h2>
				<p class="title">Name</p>
				<h2 class="content"><?php echo  $row['email'];?></h2>
				<p class="title">Email</p>
				<h2 class="content"><?php echo  $row['contact'];?></h2>
				<p class="title">Contact</p>

	
	</div>

	<?php 
	}
		}

	?>
	<!--MODAL FOR PROFILE PICTURE UPLOAD-->
<div class="modal fade" id="adminprofileModal" tabindex="-1" aria-labelledby="adminprofileModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="adminprofileModalLabel"> UPDATE PROFILE PICTURE</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
			<form action="" method="POST" enctype="multipart/form-data">
				<input class="inputprofile btn btn-secondary" type="file" name="file">
				<input type="submit" name="submit" class="btn btn-success">
			</form>	
      </div>
    </div>
  </div>
</div>


<!--POST METHOD FOR UPLOADING PROFILE PICTURE-->
<?php
	if(isset($_POST['submit'])){
		$id=$_SESSION['adminuser_id'];
		move_uploaded_file($_FILES['file']['tmp_name'],"adminprofilepicture/".$_FILES['file']['name']);
		mysqli_query($connection,"UPDATE adminuseraccount SET profilepicture ='".$_FILES['file']['name']."' WHERE admin_id='$id'");
				
				echo "<script>alert('Profile updated successfully');</script>";
        echo "<script>document.location='adminprofile.php';</script>";
	}
?>


		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>