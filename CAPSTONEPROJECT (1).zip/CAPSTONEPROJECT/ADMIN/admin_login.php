<?php include '../DATABASE/db_admin_connection.php'?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admin login</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,700;1,300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../CSS/login.css">
</head>
<body>
	<div class="hero-img"></div>
	<h1>Online Receipt Uploader for PHINMA-UNIVERSITY OF PANGASINAN</h1>
	
	<div class="container">
		<div class="title">
			<h2>Administrator<span>Access</span></h2>
		</div>

<?php 
session_start();
if(isset($_POST['submit'])){
    
    $userName=$_POST['userName'];
    $password=$_POST['password'];
    $_SESSION['userName']= $userName;

//DEFAULT ACCOUNT
$rows =mysqli_query($adminconnection,"SELECT NULL FROM adminuseraccount LIMIT 1");
	if (mysqli_num_rows($rows)==0) { 
			$default_firstname= 'System';
			$default_lastname='Default';
			$default_username='admin';
			$default_password='admin';

				$query= "INSERT INTO adminuseraccount (firstName,lastName,userName,password) VALUES('$default_firstname','$default_lastname','$default_username','$default_password')";
				$query_run = mysqli_query($adminconnection,$query);
	
	$sql="SELECT * from adminuseraccount WHERE userName='$userName' AND password='$password'";
    $result=mysqli_query($adminconnection,$sql);
//DEFAULT ACCOUNT

    if(mysqli_num_rows($result)==1){
    	$_SESSION['userName']= $userName;
        echo "<script>document.location='index.php';</script>";
    }

    else{
        echo "<div class='alert alert-danger' role='alert'>
  			INVALID ACCOUNT
			</div>";        
    }
}
else{
    $sql="SELECT * from adminuseraccount WHERE userName='$userName' AND password='$password'";
    $result=mysqli_query($adminconnection,$sql);
    
    if(mysqli_num_rows($result)==1){
        $_SESSION['userName']= $userName;
        echo "<script>document.location='index.php';</script>";
        

    }
    else{
        echo "<div class='alert alert-danger' role='alert'>
  			INVALID ACCOUNT
			</div>";        
    }
  }  
}
?>
	<form action="" method="POST">
		<div class="field">
			<input type="text" name="userName" class="form-control" placeholder="Enter your Username">
		</div>

		<div class="field">
			<input type="password" class="form-control" name="password" placeholder="Enter your Password">
		</div>
		<div class="button">
			<input type="submit" name="submit" value="LOGIN" class="btn btn-secondary">
		
			<a href="admin_forgot_password.php">Forgot password?</a>
		</div>
		
	</form>
	</div>

</body>
</html>