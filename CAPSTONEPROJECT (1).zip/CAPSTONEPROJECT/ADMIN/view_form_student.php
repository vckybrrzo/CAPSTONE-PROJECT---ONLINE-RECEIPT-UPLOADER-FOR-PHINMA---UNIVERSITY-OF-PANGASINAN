<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
	
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<title>Edit Student Account</title>
	<!-- My CSS -->
	<style type="text/css" media="print">
		.btn{
			display: none;
		}
	</style>
	<style type="text/css">
		.container{
		 margin-top: 3rem;
		}
		h1{
			margin-bottom: 1em;
			text-align: center;
		}
		.btn{
			float: right;
			margin: 1em 0 1em 1em;
		}
	</style>

</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Student Form</h1>
			</div>
		</div>
<button class="btn btn-secondary" onclick="window.location.replace('student.php');">Back</button>
<button type="button" class="btn btn-danger" onclick="print()">Print record</button>
<?php 
//DISPLAY CURRENT SCHOOL YEAR
	$sql = mysqli_query($adminconnection,"SELECT * FROM schoolyear_and_semester WHERE status= 'current'");
	if (mysqli_num_rows($sql)>0){
		while($list = mysqli_fetch_assoc($sql)){
		$schoolyear= $list['year'];
		$semester= $list['sem'];
		}
	$id= $_GET['viewform'];
	$query = "SELECT * FROM student_form WHERE (approval='approved' OR approval='semi-approved') AND schoolyear='$schoolyear' AND semester ='$semester' AND student_id ='$id'";
	$query_run = mysqli_query($adminconnection, $query);
//DISPLAY CURRENT SCHOOL YEAR
?>	
			<?php
				if (mysqli_num_rows($query_run) >0) {
					while($row = mysqli_fetch_assoc($query_run))
					{	
						$amount= $row['amount'];
						$format= number_format($amount,2);
				?>
		<table class="table table-hover table-bordered" id="datatable" cellspacing="0">

		<tbody id="myTable">

				<tr>
					<th scope="col">School Year</th>
					<td><?php echo $row['schoolyear'];?></td>
				</tr>

				<tr>
					<th scope="col">Semester</th>
					<td><?php echo strtoupper($row['semester']);?></td>
				</tr>

				<tr>
					<th scope="col">First Name</th>
					<td><?php echo strtoupper($row['firstname']);?></td>
				</tr>

				<tr>
					<th scope="col">Last Name</th>
					<td><?php echo strtoupper($row['lastname']);?></td>
				</tr>

				<tr>
					<th scope="col">Student Number</th>
					<td><?php echo $row['student_id'];?></td>
				</tr>

				<tr>
					<th scope="col">Email</th>
					<td><?php echo $row['email'];?></td>
				</tr>

				<tr>
					<th scope="col">Contact Number</th>
					<td><?php echo $row['contact'];?></td>
				</tr>

				<tr>
					<th scope="col">Periodic Type</th>
					<td><?php echo $row['periodic'];?></td>
				</tr>

				<tr>
					<th scope="col">Date</th>
					<td><?php echo $row['date'];?></td>
				</tr>

				<tr>
					<th scope="col">Amount</th>
					<td><?php echo $format;?></td>
				</tr>

				<tr>
					<th scope="col">Image</th>
					<td>
						<a href="../upload/<?php echo $row['image'];?>"><?php echo '<img src="../upload/'.$row['image'].'" width="100px" height="100px">'?></a>
					</td>
				</tr>
		</tbody>
	</table>
	<br><br>
	<?php
		}
	}

	else{
	?>
	<div style="margin: 10em 0; text-align: center;">
		<h2>No record</h2>
	</div>
	<?php
		}
	}
	?>

	</div>

</body>
</html>