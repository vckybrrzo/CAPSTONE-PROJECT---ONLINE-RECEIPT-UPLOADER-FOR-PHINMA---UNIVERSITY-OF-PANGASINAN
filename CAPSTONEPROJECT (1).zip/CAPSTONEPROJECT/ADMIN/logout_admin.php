<?php
session_start();
unset($_SESSION['userName']);
header('location:admin_login.php')
?>