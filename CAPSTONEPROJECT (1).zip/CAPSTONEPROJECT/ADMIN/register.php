<?php include '../DATABASE/db_admin_connection.php'?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,700;1,300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../CSS/login.css">
	<style type="text/css">
div .row{
	margin: 1em 0;
}	

div .button{
 margin-right: 0;
}

.container{
	height: auto;
}

label{
	font-weight: bold;
}
.row input{
	border-radius: .3em;
	background-color: lightgray;
}

	</style>

</head>
<body>
	<div class="hero-img"></div>
	<div class="container">
		<div class="title">
			<h1>Online Receipt Uploader for PHINMA-UNIVERSITY OF PANGASINAN</h1>
		</div>
<?php 
if (isset($_POST['register']))

{

	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$userName = $_POST['userName'];
	$password = $_POST['password'];
	$repassword= $_POST['repassword'];
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	
$check_userName = mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE userName='$userName'");
if(mysqli_num_rows($check_userName)==1){
		echo $error= "<div class='alert alert-danger' role='alert'>
  			Username is already taken!
			</div>"; 
	}

if($password != $repassword){
	echo $error = "<div class='alert alert-danger' role='alert'>
  			password does not match!
			</div>"; 
}

else{

	$query= "INSERT INTO adminuseraccount (firstName,lastName,userName,password,email,contact) VALUES ('$firstName','$lastName','$userName','$password','$email','$contact')";
	$query_run = mysqli_query($adminconnection,$query);
	 if($query_run)
    {	
        echo "<script>alert('Refgister Successful!');</script>";
        echo "<script>document.location='admin_login.php';</script>";  
    }
	}
}

 ?>
		<form method="POST">
	<div class="row">
				<div class="col-md-6">
					<label>First Name</label>
					<input type="text" name="firstName" class="form-control" placeholder="First Name" required>
				</div>	
				<div class="col-md-6">
					<label>Last Name</label>
					<input type="text" name="lastName" class="form-control" placeholder="Last Name" required>
				</div>	
				</div>

			<div class="row">
				<div class="col-md-6">
				<label>Username</label>
				<input type="text" name="userName" class="form-control" placeholder="Username" required>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
				<label>Password</label>
				<input type="password" name="password" class="form-control" placeholder="Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
				</div>
				<div class="col-md-6">
				<label>Comfirm Password</label>
				<input type="password" name="repassword" class="form-control" placeholder="Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
				<label>Email</label>
				<input type="text" name="email" class="form-control" placeholder="Email" required>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6">
				<label>Contact Number</label>
				<input type="text" name="contact" class="form-control" placeholder="Contact" required>
				</div>
			</div>
			
			<div class="button">
			<a href="admin_login.php" type="button" class="btn btn-secondary">Back</a>
			<button type="submit" name="register" class="btn btn-success">Register</button>
			</div>
		</div>
	</form>
	</div>

</body>
</html>