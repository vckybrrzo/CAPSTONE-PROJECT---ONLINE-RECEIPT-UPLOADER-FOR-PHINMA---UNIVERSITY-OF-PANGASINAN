<?php include_once 'session_admin.php'?>
<?php
include'../DATABASE/db_student_connection.php';
include '../DATABASE/db_admin_connection.php';


if(isset($_GET['delete']))
{
	$id=$_GET['delete'];
	$userLevel= $_GET['userLevel'];
		?>
			 <!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "";
			if($userLevel == "admin"){
				$studentquery = "SELECT * FROM adminuseraccount WHERE userName='$id'";
			}
			else{
				$studentquery = "SELECT * FROM secretaryuseraccount WHERE userName='$id'";
			}
			$studentquery_run = mysqli_query($adminconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstName= $row['firstName'];
			$lastName= $row['lastName'];
			$userName= $row['userName'];

			$action='Delete a user account [NAME: '.$firstName.' '.$lastName.' Username: '.$userName.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
	<?php
	if($userLevel == "admin"){
		mysqli_query($adminconnection,"DELETE FROM adminuseraccount WHERE userName='$id'");
	}
	else{
		mysqli_query($adminconnection,"DELETE FROM secretaryuseraccount WHERE userName='$id'");
	}
		echo "<script>alert('Admin account was deleted successfully');</script>";
    echo "<script>document.location='user_account.php';</script>";

}

 ?>