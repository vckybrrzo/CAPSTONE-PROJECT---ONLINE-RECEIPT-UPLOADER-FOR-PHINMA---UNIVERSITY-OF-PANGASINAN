<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
	
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<title>Student Account</title>
	<!-- My CSS -->
	<style type="text/css" media="print">
		.btn{
			display: none;
		}
	</style>
	<style type="text/css">
		.container{
		 margin-top: 3rem;
		 
		}
		h1{
			margin-bottom: 1em;
			text-align: center;
		}
		.btn{
			float: right;
			margin: 1em 0 1em 1em;
		}
	</style>

</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Student Form</h1>
			</div>
		</div>

	<?php 
		$id= $_GET['viewuser'];
		$query = "SELECT * FROM studentaccount WHERE studentNumber= '$id'";
		$query_run = mysqli_query($studentconnection, $query);
	?>
<button class="btn btn-secondary" onclick="window.location.replace('student.php');">Back</button>
<button type="button" class="btn btn-danger" onclick="print()">Print record</button>

		<table class="table table-hover table-bordered" id="datatable" cellspacing="0">

		<tbody id="myTable">

			<?php
				if (mysqli_num_rows($query_run) >0) {
					while($row = mysqli_fetch_assoc($query_run))
					{	
				?>
				<tr>
					<th scope="col">Last Name</th>
					<td><?php echo strtoupper($row['lastName']);?></td>
				</tr>

				<tr>
					<th scope="col">First Name</th>
					<td><?php echo strtoupper($row['firstName']);?></td>
				</tr>

				<tr>
					<th scope="col">Student Number</th>
					<td><?php echo $row['studentNumber'];?></td>
				</tr>

				<tr>
					<th scope="col">Password</th>
					<td><?php echo $row['password'];?></td>
				</tr>

				<tr>
					<th scope="col">Email</th>
					<td><?php echo $row['email'];?></td>
				</tr>

				<tr>
					<th scope="col">Contact Number</th>
					<td><?php echo $row['contact'];?></td>
				</tr>

				<tr>
					<th scope="col">Course</th>
					<td><?php echo $row['course'];?></td>
				</tr>
		</tbody>
	</table>

	<?php
		}
	}
	?>
	</div>

</body>
</html>