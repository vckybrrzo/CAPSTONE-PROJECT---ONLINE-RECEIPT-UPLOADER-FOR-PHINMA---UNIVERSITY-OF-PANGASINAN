<?php include 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php 
if (isset($_POST['addaccount'])){

	$userLevel = $_POST['userLevel'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$userName = $_POST['userName'];
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	
	if($userLevel == "admin"){
		$checkusername = mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE userName ='$userName'");
		if(mysqli_num_rows($checkusername)>0){
					echo "<script>alert('Username was already exist, Please use other username');</script>";
					echo "<script>document.location='user_account.php';</script>";
					exit();
		}
		$query= "INSERT INTO adminuseraccount (firstName,lastName,userName,email,contact,password) VALUES ('$firstName','$lastName','$userName','$email','$contact','$lastName')";
		$query_run = mysqli_query($adminconnection,$query);
		if($query_run)
			{	
					echo "<script>alert('Admin account was successfully added');</script>";
					echo "<script>document.location='user_account.php';</script>";

				// <!--ACTIVITY LOGS-->
				$admin=$_SESSION['userName'];
				$action='Added a user account [NAME: '.$firstName.' '.$lastName.' USERNAME: '.$userName.']';
					$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
					$query_run = mysqli_query($adminconnection,$query);
				// <!--ACTIVITY LOGS-->

				
			}
		else
			{
					echo "<script>alert('upload not successful!');</script>";
					echo "<script>document.location='user_account.php';</script>";
			}
	}
	// if secretary
	else{
		$checkusername = mysqli_query($adminconnection,"SELECT * FROM secretaryuseraccount WHERE userName ='$userName'");
		if(mysqli_num_rows($checkusername)>0){
					echo "<script>alert('Username was already exist, Please use other username');</script>";
					echo "<script>document.location='user_account.php';</script>";
					exit();
		}
		$query= "INSERT INTO secretaryuseraccount (firstName,lastName,userName,email,contact,password) VALUES ('$firstName','$lastName','$userName','$email','$contact','$lastName')";
		$query_run = mysqli_query($adminconnection,$query);
		if($query_run)
			{	
					echo "<script>alert('Secretary account was successfully added');</script>";
					echo "<script>document.location='user_account.php';</script>";

				// <!--ACTIVITY LOGS-->
				$admin=$_SESSION['userName'];
				$action='Added a user account [NAME: '.$firstName.' '.$lastName.' USERNAME: '.$userName.']';
					$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
					$query_run = mysqli_query($adminconnection,$query);
				// <!--ACTIVITY LOGS-->

				
			}
		else
			{
					echo "<script>alert('upload not successful!');</script>";
					echo "<script>document.location='user_account.php';</script>";
			}
	}
}

 ?>