<?php include '../DATABASE/db_admin_connection.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include_once 'session_admin.php'?>

<!--NOTIFICATION -->
<?php
	if(isset($_GET['notif'])){
		$id=$_GET['notif'];
		mysqli_query($adminconnection,"UPDATE admin_notification SET status='1' WHERE id='$id'");
	}
?>
<!--NOTIFICATION -->

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT -->
	<meta http-equiv="refresh" content="5120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<!--SCRIPT FOR SEARCH BAR-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS IN PAGINATION-->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
	<!-- My CSS -->
	<link rel="stylesheet" href="../CSS/style.css">
	<style type="text/css">
		
.modal-button{
	margin: 2em 0 1em 1em;
}

.modal-body .input-group input{
	margin-bottom: 2em;

}

.modal-body input{
	margin-bottom: 2em;

}

.modal-body select{
	margin-bottom: 2em;

}

	</style>

	<title>User Account</title>
</head>
<body>

<!--PHP Getting Name-->
	<?php
	$id=$_SESSION['userName'];
	$adminquery="SELECT * FROM adminuseraccount WHERE userName='$id'";
	$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>
<!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run)){
		if($row['profilepicture']==""){
			$default ="<img src='adminprofilepicture/default.png' alt='default profile'";
			}
		else{
			$default ="<img src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
			}
	?>

	<!-- SIDEBAR -->
	<section id="sidebar" class="hide">
		<a href="#" class="brand">
			<i class='bx bx-archive-out'></i>
			<span class="text"><span>UPANG<span class="subtitle"> RECEIPT UPLOADER</span></span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="student.php">
					<i class='bx bxs-user-circle'></i>
					<span class="text">Students</span>
				</a>
			</li>
			<li>
				<a href="request.php">
					<i class='bx bxs-help-circle' ></i>
					<span class="text">Request</span>
				</a>
			</li>
			<li class="active">
				<a href="#">
					<i class='bx bxs-group'></i>
					<span class="text">User Accounts</span>
				</a>
			</li>
			<li>
				<a href="user_logs.php">
					<i class='bx bxs-notepad'></i>
					<span class="text">User logs</span>
				</a>
			</li>
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>			
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu'></i>
			<form action="#">
				<div class="form-input">
					<h3>Administration Center</h3>
				</div>
			</form>

<!--NOTIFICATION-->
			<div class="btn-group" role="group">
			    <button id="btnGroupDrop" type="button" class="btn dropdown-toggle " data-bs-toggle="dropdown" aria-expanded="false" style="background-color:transparent"><i class='bx bxs-bell'>
			<?php
				$requestquery="SELECT * FROM admin_notification WHERE status='0'";
				$requestquery_run = mysqli_query($adminconnection, $requestquery);
				$totalrequest = mysqli_num_rows($requestquery_run);
				if ($totalrequest>0) {
					echo "<span class='num'>$totalrequest</span>";
				}
				?>
			</i></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop">
		   	 	<?php 
		   	 	$requestquery1 =mysqli_query($adminconnection,"SELECT * FROM admin_notification WHERE status='0'");
				if (mysqli_num_rows($requestquery1)>0) {
					while($result =mysqli_fetch_assoc($requestquery1)){
						echo '<li><a class="dropdown-item" href="request.php?notif='.$result['id'].'"><span style="font-weight:bold;">'.$result['studentNumber'].' '.$result['fullName'].'</span><br> '.$result['description'].' '.$result['periodic'].' form</a></li>';
						echo '<div class="dropdown-divider"></div>';
					}
				}
				else{
					echo '<li><a class="dropdown-item text-danger" href="">No notification</a></li>';
				}
				 ?>	
			    </ul>
		  	</div>
<!--NOTIFICATION-->

			<div class="btn-group" role="group">
			    <button id="btnGroupDrop1" type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Welcome, <?php echo strtoupper($row['userName']);?></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
			      <li><a class="dropdown-item" href="admin_profile.php">profile</a></li>
			      <li><a class="dropdown-item" href="change_password.php">change password</a></li>
			      <li><a class="dropdown-item" href="logout_admin.php" onClick ="return confirm('Are you  sure you want to logout?');" style="color: red;">Logout</a></li>
			    </ul>
	  		</div>

			<a href="#" class="profile">
				<?php echo $default;?> 
			</a>
		</nav>
		<!-- NAVBAR -->

<?php 
}
	}
?>		


<!-- MAIN -->
<main>
	<div class="head-title">
		<div class="left">
			<h1>Users Account</h1>
		</div>
		<a href="print_useraccount_records.php" class="btn-download">
			<i class='bx bxs-cloud-download' ></i>
			<span class="text">Print Records</span>
		</a>
	</div>
			 	

<!-- Button trigger modal -->
<div class="modal-button">
	<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class='bx bxs-user-plus'></i> Add User account</button>
</div>


<?php  

?>

	<?php 
		$query = "SELECT * FROM adminuseraccount ORDER BY lastName ASC";
		$query_run = mysqli_query($adminconnection, $query);	
	?>	

	<div class="table-responsive table1">
		<table class="table table-hover table-bordered" id="datatable" cellspacing="0">
		<thead>
			<tr style="background-color: #647842; color: white;">
				<th>Last Name</th>
				<th>First Name</th>
				<th>Username</th>
				<th>Password</th>
				<th>Email Address</th>
				<th>Contact Number</th>
				<th>User Level</th>
				<th>Option</th>
			</tr>
		</thead>
		<tbody id="myTable">

			<?php
				if (mysqli_num_rows($query_run) >0) {
					while($row = mysqli_fetch_assoc($query_run))
					{	
				?>

				<tr>
					<td><?php echo $row['lastName'];?></td>
					<td><?php echo $row['firstName'];?></td>
					<td><?php echo $row['userName'];?></td>
					<td><?php echo $row['password'];?></td>
					<td><a href=""><?php echo $row['email'];?></a></td>
					<td><?php echo $row['contact'];?></td>
					<td>Admin</td>
					<td style="text-align: center; align-content: center; width: 7em;"><form method="POST" action="">
						<a href="view_user_account.php?viewuser=<?php echo $row['userName'];?>&userLevel=admin" class="btn btn-success btn-sm"><i class='bx bxs-show'></i></a>

						<a href="edit_user_account.php?edit=<?php echo $row['userName'];?>&userLevel=admin" class="btn btn-primary btn-sm"><i class='bx bxs-edit-alt'></i></a>

						<a href="db_delete_user_account.php?delete=<?php echo $row['userName'];?>&userLevel=admin" onClick ="return confirm('Do you really want to delete this record?');" class="btn btn-danger btn-sm"><i class='bx bxs-trash'></i></a>
						
					</form>
					</td>
				</tr>
				<?php
					}
				}
				else{
						?>
						<tr>
							<td colspan="7" style="text-align: center;">No record</td>
						</tr>
					<?php
				}
			?>

			<?php 
					$secQuery = "SELECT * FROM secretaryuseraccount ORDER BY lastName ASC";
					$runQuery = mysqli_query($adminconnection, $secQuery);	
					if (mysqli_num_rows($runQuery) >0) {
					while($row = mysqli_fetch_assoc($runQuery))
					{	
				?>
				<tr>
					<td><?php echo $row['lastName'];?></td>
					<td><?php echo $row['firstName'];?></td>
					<td><?php echo $row['userName'];?></td>
					<td><?php echo $row['password'];?></td>
					<td><a href=""><?php echo $row['email'];?></a></td>
					<td><?php echo $row['contact'];?></td>
					<td>Secretary</td>
					<td style="text-align: center; align-content: center; width: 7em;"><form method="POST" action="">
						<a href="view_user_account.php?viewuser=<?php echo $row['userName'];?>&userLevel=secretary" class="btn btn-success btn-sm"><i class='bx bxs-show'></i></a>

						<a href="edit_user_account.php?edit=<?php echo $row['userName'];?>&userLevel=secretary" class="btn btn-primary btn-sm"><i class='bx bxs-edit-alt'></i></a>

						<a href="db_delete_user_account.php?delete=<?php echo $row['userName'];?>&userLevel=secretary" onClick ="return confirm('Do you really want to delete this record?');" class="btn btn-danger btn-sm"><i class='bx bxs-trash'></i></a>
						
					</form>
					</td> 
				</tr>
				<?php
					}
				}
			?>	

		</tbody>
	</table>
</div>
	
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 99999;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">ADD USER ACCOUNT</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      	<form action="db_adding_user.php" method="POST" enctype="multipart/form-data">

        <div class="input-group">
			    <input type="text" placeholder="First Name" name="firstName" class="form-control" pattern="[a-zA-z ]{2,100}" required>
			    <input type="text" placeholder="Last Name" name="lastName" class="form-control" pattern="[a-zA-z ]{2,100}" required>
				</div>
					<input type="text" name="userName" placeholder="Username" class="form-control" required>
					<input type="email" name="email" placeholder=" Email Address" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
					<input type="text" name="contact" placeholder="Contact Number" class="form-control" pattern="[0-9]{11}" title="invalid number and use the proper format example: 09876543210" required>	
			    <div class="form-check">
						<input class="form-check-input" value="admin" type="radio" name="userLevel" id="radioBtnAdmin" checked>
						<label class="form-check-label" for="radioBtnAdmin">
							Admin
						</label>
					</div>
					<div class="form-check">
						<input class="form-check-input" value="secretary" type="radio" name="userLevel" id="radioBtnSecretary" >
						<label class="form-check-label" for="radioBtnSecretary">
							Secretary
						</label>
					</div>

      </div>
      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-success" name="addaccount" onclick="return confirm('Do you really want to add this account?');">add</button>
    	</div>
     		</form>
    </div>
  </div>
</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

<script src="script.js"></script>
<!-- My SCRIPT IN PAGINATION AND SEARCH-->
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
    $('#datatable').DataTable();
} );
	</script>
<!-- My SCRIPT IN PAGINATION AND SEARCH-->		
</body>
</html>