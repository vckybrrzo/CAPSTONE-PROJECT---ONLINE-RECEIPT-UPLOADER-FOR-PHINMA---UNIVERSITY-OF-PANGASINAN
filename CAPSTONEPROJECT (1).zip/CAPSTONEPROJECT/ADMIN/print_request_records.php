<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<title>Print</title>
	<style type="text/css" media="print">
		.nonprint{
			display: none;
			visibility: none;
		}

	</style>
</head>

<body onload="print()">

<center>
	
			<?php 
//DISPLAY CURRENT SCHOOL YEAR
	$sql = mysqli_query($adminconnection,"SELECT * FROM schoolyear_and_semester WHERE status= 'current'");
	if (mysqli_num_rows($sql)>0){
		while($list = mysqli_fetch_assoc($sql)){
		$schoolyear= $list['year'];
		$semester= $list['sem'];
		}

		$query = "SELECT * FROM student_form WHERE approval='' AND schoolyear='$schoolyear' AND semester ='$semester' ORDER BY lastname ASC";
		$query_run = mysqli_query($adminconnection, $query);
//DISPLAY CURRENT SCHOOL YEAR
	?>	

	<div class="table-responsive table1">

		<h1>REQUEST RECORDS</h1>
		<button class="btn btn-info nonprint" onclick="window.location.replace('request.php');" style="float: right; margin: 1em;">CANCEL PRINT</button>

		<table class="table table-hover table-bordered" id="datatable" cellspacing="0">
		<thead>
			<tr>
				<th>Student Number</th>				
				<th>Last Name</th>
				<th>First Name</th>
				<th>Email Address</th>
				<th>Contact Number</th>
				<th>fee Type</th>
				<th>Date</th>
				<th>Amount</th>	
				<th>Uploaded file</th>
			</tr>
		</thead>
		<tbody id="myTable">

			<?php
				if (mysqli_num_rows($query_run) >0) {
					while($row = mysqli_fetch_assoc($query_run))
					{	
						$amount= $row['amount'];
						$format= number_format($amount,2);
				?>

				<tr>
					<td><?php echo $row['student_id']; ?></td>		
					<td><?php echo strtoupper($row['lastname']);?></td>
					<td><?php echo strtoupper($row['firstname']); ?></td>
					<td><a href=""><?php echo $row['email'];?></a></td>
					<td><?php echo $row['contact']; ?></td>
					<td><?php echo $row['periodic']; ?></td>
					<td><?php echo $row['date']; ?></td>
					<td>₱ <?php echo $format;?></td>
					<td>
						<a href="../upload/<?php echo $row['image'];?>"><?php echo '<img src="../upload/'.$row['image'].'" width="100px" height="100px">'?></a>
					</td>
				</tr>

					<?php
					}
				}
			}
					else{
						?>
						<tr>
							<td colspan="9">No record</td>
						</tr>
					<?php
				}

				?>

		</tbody>
	</table>
</center>

</body>
</html>
