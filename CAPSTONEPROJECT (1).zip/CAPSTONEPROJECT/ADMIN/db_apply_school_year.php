<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php
$id=$_GET['apply'];
	$sql = mysqli_query($adminconnection,"SELECT * FROM schoolyear_and_semester WHERE sy_id='$id'");
	$row = mysqli_fetch_assoc($sql);
	$schoolyear= $row['year'];
	$semester= $row['sem'];
	
//SET BUTTON INTO CURRENT
	mysqli_query($adminconnection,"UPDATE schoolyear_and_semester SET status='current' WHERE sy_id ='$id'");
//SET BUTTON INTO OLD
	mysqli_query($adminconnection,"UPDATE schoolyear_and_semester SET status='old' WHERE sy_id !='$id'");
//SET FORM INTO CURRENT SCHOOL YEAR
	mysqli_query($adminconnection,"ALTER TABLE student_form ALTER schoolyear SET DEFAULT '$schoolyear'");
//SET FORM INTO CURRENT SEMESTER
	mysqli_query($adminconnection,"ALTER TABLE student_form ALTER semester SET DEFAULT '$semester'");
//SET ACTIVITY LOG INTO CURRENT SCHOOL YEAR
	mysqli_query($adminconnection,"ALTER TABLE activitylog ALTER schoolyear SET DEFAULT '$schoolyear'");
//SET ACTIVITY LOG INTO CURRENT SEMESTER
	mysqli_query($adminconnection,"ALTER TABLE activitylog ALTER semester SET DEFAULT '$semester'");

?>
			<!--ACTIVITY LOGS-->
			<?php 
			$admin=$_SESSION['userName'];
			$action='Applied a School Year [SCHOOL YEAR: '.$schoolyear.' SEMESTER: '.$semester.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->

	<?php			 
		 echo "<script>alert('applied school year was successfully');</script>";
       	 echo "<script>document.location='settings.php';</script>";
?>